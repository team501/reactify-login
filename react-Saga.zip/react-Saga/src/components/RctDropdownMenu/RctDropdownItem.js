//Rct Dropdown item

import React, { Fragment } from 'react';

function RctDropdownItem({children}){
   return (
      <Fragment>
         {children}
      </Fragment>
   )
}
export default RctDropdownItem;